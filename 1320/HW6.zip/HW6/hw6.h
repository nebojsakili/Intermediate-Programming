#ifndef HOMEWORK6_H
#define HOMEWORK6_H


/*Functions for Prompt 1*/
void add_tips(); //call to insert tips until done is entered
void tips_earned(); //call to pay out employees as well as print the current status of the tip jar

void customer_info(QUEUE* q); //retrieves information from file and enqueues it
void flight_check(QUEUE *q, int flight_number);



#endif